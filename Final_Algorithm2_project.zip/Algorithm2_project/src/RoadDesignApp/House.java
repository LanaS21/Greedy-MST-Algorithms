/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RoadDesignApp;

import java.util.Objects;

import graphFramework.Vertex;

/**
 *
 * @author Lan
 */
public class House extends Vertex {
	String HouseName;

	public House() {
		super(0);
	}

	public House(int label, House house) {
		super(label);
		this.HouseName = house.HouseName;

	}

	public House(int label, String HouseName) {
		super(label);
		this.HouseName = HouseName;
	}

	public House(String HouseName) {
		this.HouseName = HouseName;
	}

	// @Override
	public void displayInfo() {

		// House name. A – House name. B : road name: road x1 road size: 20
		System.out.println("House name. " + HouseName);
		;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		House other = (House) obj;
		return Objects.equals(HouseName, other.HouseName);
	}

	@Override
	public String toString() {
		return "House name. " + HouseName;
	}

}
