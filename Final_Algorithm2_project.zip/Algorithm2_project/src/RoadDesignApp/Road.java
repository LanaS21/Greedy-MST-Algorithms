/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RoadDesignApp;

import graphFramework.Edge;
import graphFramework.Vertex;

/**
 *
 * @author Lan
 */
public class Road extends Edge {
	int roadSize;

	public Road(Vertex source, Vertex target, int weight) {
		super(source, target, weight);
		roadSize = weight * 3;
	}

	public Road() {

	}

	@Override
	public void displayInfo() {
//		super.displayInfo();
//		System.out.println(" : road name: road x"+super.weight+" road size: " + roadSize);
	}

}
