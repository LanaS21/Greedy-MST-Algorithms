/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RoadDesignApp;

import java.io.FileNotFoundException;

import graphFramework.*;

/**
 *
 * @author Lan
 */
public class RoadDesignApp {

	public static void main(String[] args) throws FileNotFoundException {

//		Graph cityMap = new Graph();
//		cityMap.readGraphFromFile("input.txt");
		Graph cityMap = new Graph(1000, 25000, false);
		cityMap.makeGraph();
		KruskalAlg K = new KruskalAlg(cityMap);
		PQPrimAlg P = new PQPrimAlg(cityMap);

		long kruskalStart = System.currentTimeMillis(); // start time
		K.kruskal(cityMap);
		K.DisplayResultingMST();
		long kruskalEnd = System.currentTimeMillis();
		//System.out.println("\n-----------------------");
		long PQStart = System.currentTimeMillis(); // start time
		P.PQ(cityMap);
		P.DisplayResultingMST();
		long PQEnd = System.currentTimeMillis();

		System.out.println("\n-----------------------");
		System.out.println("Total runtime of Priority queue's Algorithm :  " + (PQEnd - PQStart) + " MS");
		System.out.println("Total runtime of Kruskal's Algorithm :  " + (kruskalEnd - kruskalStart) + " MS");

	}
}
