/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphFramework;

/**
 *
 * @author Lan
 */
public class Edge implements Comparable<Edge> {

	public int weight;
	public Vertex source;
	public Vertex target;
	public Vertex parent;

	public Edge() {

	}

	public Edge(Vertex source, Vertex target, int weight) {
		this.source = source;
		this.target = target;
		this.weight = weight;
	}

	public int compareTo(Edge other) {
		return weight - other.weight;
	}

	public void displayInfo() {
		System.out.print(source + " - " + target);

	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public int getWeight() {
		return weight;
	}

}
